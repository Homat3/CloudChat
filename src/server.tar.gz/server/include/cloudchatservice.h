#ifndef CLOUDCHAT_SERVICE
#define CLOUDCHAT_SERVICE

#include "cloudchatdat.h"
#include "cloudchatmsg.h"

void Login(server_t& cloudchat_srv, websocketpp::connection_hdl hdl, LoginMsg* msg);
void LoginByToken(server_t& cloudchat_srv, websocketpp::connection_hdl hdl, LoginByTokenMsg* msg);
void Register(server_t& cloudchat_srv, websocketpp::connection_hdl hdl, RegisterMsg* msg);

#endif // CLOUDCHAT_SERVICE
