#include "cloudchatservice.h"

void Login(server_t& cloudchat_srv, websocketpp::connection_hdl hdl, LoginMsg* msg) {
	// TODO: 账密登录业务
	std::cout << "username: " << msg->get_username() << std::endl;
	std::cout << "password: " << msg->get_password() << std::endl;
}

void LoginByToken(server_t& cloudchat_srv, websocketpp::connection_hdl hdl, LoginByTokenMsg* msg) {
	// TODO: 令牌登录业务
}

void Register(server_t& cloudchat_srv, websocketpp::connection_hdl hdl, RegisterMsg* msg) {
	// TODO: 注册业务
}
